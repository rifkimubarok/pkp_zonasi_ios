//
//  PembelajaranItemCell.swift
//  CollectionVIew
//
//  Created by Rifki Mubarok on 26/11/19.
//  Copyright © 2019 Dirjen GTK Kemdikbud-DIKTI. All rights reserved.
//

import UIKit

class PembelajaranItemCell: UICollectionViewCell {

    @IBOutlet weak var course_image: UIImageView!
    
    @IBOutlet weak var course_name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
